"""Análisis descriptivos sobre perfiles preservados, sin reajustar modelos."""
from __future__ import annotations
import copy
import hashlib
import json
import math
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.2.0"
PROVINCES = ["Catamarca", "La Rioja", "Santiago del Estero"]
PROPOSALS = [
    (0, "Proyectos y ejecución de actividades", "Incluye iniciativas productivas y otras actividades organizadas mediante proyectos.", ["DOC_009_CH_0026", "DOC_003_CH_0004"]),
    (1, "Competencias y articulación institucional", "Agrupa referencias a autoridades, jurisdicciones, municipios y adhesiones.", ["DOC_013_CH_0004", "DOC_014_CH_0003"]),
    (2, "Promoción y financiamiento", "Reúne fondos, microcrédito y mecanismos de apoyo financiero.", ["DOC_012_CH_0007", "DOC_009_CH_0153"]),
    (3, "Programas y comunicación de gestión", "Vincula programas con piezas y actividades de comunicación gubernamental.", ["DOC_007_CH_0003", "DOC_007_CH_0004", "DOC_011_CH_0002"]),
    (4, "Tareas y gestión de información", "Incluye tareas, relevamientos, bases de datos y etapas de trabajo; puede reflejar el género del informe.", ["DOC_002_CH_0005", "DOC_007_CH_0017"]),
    (5, "Plazos, obligaciones y sanciones", "Incluye plazos financieros y obligaciones normativas; requiere revisar sus usos heterogéneos.", ["DOC_009_CH_0193", "DOC_015_CH_0029"]),
    (6, "Adhesión y condiciones de beneficios", "Reúne beneficios, compromisos y condiciones de acceso o mantenimiento.", ["DOC_018_CH_0007", "DOC_016_CH_0003"]),
    (7, "Permisos y regulación de actividades", "Incluye permisos y operadores, junto con otros pasajes cuya afinidad necesita revisión contextual.", ["DOC_015_CH_0019", "DOC_019_CH_0002"]),
]


def normalize(value):
    return "".join(c for c in unicodedata.normalize("NFKD", str(value or "")) if not unicodedata.combining(c)).lower().replace("_", " ")


def vector(doc, layer):
    values = list(doc.get("profiles", {}).get(layer, {}).values())
    if not values or any(v is None or not math.isfinite(float(v)) for v in values):
        return None
    a = np.asarray(values, dtype=float)
    return a / a.sum() if a.sum() > 0 else None


def matches(doc, payload, context=None, ignore_province=False, ignore_exclusions=False):
    c = context or {}
    if not doc["full"] or doc["regional"] or not doc["compare"]:
        return False
    if not ignore_province and c.get("province", "all") not in ("all", doc["province"]):
        return False
    if c.get("source", "all") not in ("all", doc["source"]):
        return False
    if c.get("period", "all") not in ("all", doc["period"]):
        return False
    if c.get("universe") == "common":
        common = {r["uid"] for r in payload["coverage"] if r["initial_fulltext"] and r["refined_fulltext"]}
        if doc["uid"] not in common:
            return False
    if not ignore_exclusions and doc["uid"] in c.get("excluded", []):
        return False
    if c.get("query") and normalize(c["query"]) not in normalize(doc["title"] + " " + doc["summary"] + " " + payload["texts"].get(doc["text"], "")):
        return False
    return True


def selected_docs(payload, stage_id, layer="bt", context=None, ignore_province=False, ignore_exclusions=False):
    stage = next(s for s in payload["stages"] if s["id"] == stage_id)
    return [d for d in stage["documents"] if matches(d, payload, context, ignore_province, ignore_exclusions) and vector(d, layer) is not None]


def weights(docs, mode="documents"):
    if not docs:
        return None
    if mode == "documents":
        return np.full(len(docs), 1 / len(docs))
    counts = {s: sum(d["source"] == s for d in docs) for s in ["CFI", "SAIJ"]}
    if not all(counts.values()):
        return None
    return np.asarray([.5 / counts[d["source"]] for d in docs], dtype=float)


def mean_profile(docs, layer="bt", mode="documents"):
    w = weights(docs, mode)
    return np.sum(np.asarray([vector(d, layer) for d in docs]) * w[:, None], axis=0) if w is not None else None


def provincial_profiles(payload, stage_id, layer="bt", context=None, ignore_province=False):
    ds = selected_docs(payload, stage_id, layer, context, ignore_province)
    rows = []
    for province in PROVINCES:
        group = [d for d in ds if d["province"] == province]
        observed, balanced = mean_profile(group, layer), mean_profile(group, layer, "sources")
        rows.append({"province": province, "docs": group, "n": len(group), "cfi": sum(d["source"] == "CFI" for d in group), "saij": sum(d["source"] == "SAIJ" for d in group), "observed": observed, "balanced": balanced})
    return rows


def influence(payload, stage_id, province, topic, layer="bt", mode="documents", context=None):
    c = dict(context or {}, province=province)
    docs = selected_docs(payload, stage_id, layer, c)
    mean = mean_profile(docs, layer, mode)
    if mean is None or topic >= len(mean):
        return []
    w = weights(docs, mode)
    topic_mass = float(mean[topic])
    rows = []
    for i, doc in enumerate(docs):
        remaining = [d for d in docs if d["uid"] != doc["uid"]]
        without = mean_profile(remaining, layer, mode)
        contribution = float(w[i] * vector(doc, layer)[topic] / topic_mass) if topic_mass else None
        rows.append({"stage": stage_id, "layer": layer, "province": province, "topic": topic, "mode": mode, "doc_id": doc["id"], "uid": doc["uid"], "title": doc["title"], "source": doc["source"], "n_active": len(docs), "document_weight": float(w[i]), "document_affinity": float(vector(doc, layer)[topic]), "contribution_share": contribution, "mean_current": topic_mass, "mean_without_document": float(without[topic]) if without is not None else None, "delta_pp": float(100 * (without[topic] - topic_mass)) if without is not None else None, "leader_before": int(np.argmax(mean)), "leader_after": int(np.argmax(without)) if without is not None else None, "balance_lost": bool(mode == "sources" and remaining and without is None), "profiles_frozen": True})
    return rows


def concentration(payload, stage_id, layer="bt", mode="documents", context=None):
    groups = provincial_profiles(payload, stage_id, layer, context, ignore_province=True)
    key = "balanced" if mode == "sources" else "observed"
    available = [g for g in groups if g[key] is not None]
    if not available:
        return []
    reference = np.mean([g[key] for g in available], axis=0)
    rows = []
    for group in groups:
        p = group[key]
        for topic, r in enumerate(reference):
            docs = group["docs"]
            support = [d for d in docs if vector(d, layer)[topic] >= np.sort(vector(d, layer))[-min(2, len(reference))] - 1e-9] if p is not None else []
            rows.append({"stage": stage_id, "layer": layer, "mode": mode, "province": group["province"], "topic": topic, "n_documents": group["n"], "n_cfi": group["cfi"], "n_saij": group["saij"], "affinity": float(p[topic]) if p is not None else None, "reference": float(r), "reference_provinces": len(available), "relative_concentration": float(p[topic] / r) if p is not None and r > 0 and len(available) >= 2 else None, "support_top2": len(support) if p is not None else None, "support_doc_ids": "|".join(d["id"] for d in support), "support_cfi": sum(d["source"] == "CFI" for d in support) if p is not None else None, "support_saij": sum(d["source"] == "SAIJ" for d in support) if p is not None else None, "reference_ignores_province_filter": True})
    return rows


def enrich_payload(payload):
    payload = copy.deepcopy(payload)
    payload["schema"] = "observatorio-noa-panorama/0.2"
    payload["version"] = VERSION
    payload["viewer_generated_at"] = datetime.now(timezone.utc).isoformat()
    refined = next(s for s in payload["stages"] if s["id"] == "refined")
    chunk_ids = {c["id"] for c in refined["chunks"]}
    payload["label_proposals"] = [{"stage": "refined", "layer": "bt", "topic": topic, "label": label, "description": description, "status": "proposed", "evidence_refs": [r for r in refs if r in chunk_ids], "review_note": "Propuesta interpretativa para revisar; los pasajes ilustran usos y no certifican homogeneidad del tópico."} for topic, label, description, refs in PROPOSALS]
    payload["catalogue_reviews"] = [{"stage": "refined", "doc_id": "DOC_016", "field": "title", "status": "pending", "observation": "El título catalogado menciona bosques nativos, mientras el artículo recuperado refiere a Inversiones para Bosques Cultivados. Verificar la denominación conservando el dato original.", "evidence_refs": ["DOC_016_CH_0002"]}]
    payload["analysis_methods"] = {"profiles": "Cada perfil documental se normaliza sobre los tópicos exportados y permanece fijo al excluir documentos.", "observed": "Media con igual peso por documento dentro de la provincia.", "balanced": "Media de las medias CFI y SAIJ, con peso 0.5 por fuente. No disponible cuando falta una fuente.", "contribution": "q(d,t) = w(d) p(d,t) / suma_d w(d) p(d,t). Mide aporte al promedio de afinidad, no presupuesto ni impacto.", "leave_one_out": "Se retira un documento y se recalcula el promedio con perfiles fijos. Si se pierde una fuente, el perfil equilibrado queda no disponible.", "relative_concentration": "L(p,t) = afinidad(p,t) / media de afinidad de las provincias disponibles, cada provincia con igual peso. El filtro provincial no modifica la referencia.", "support_top2": "Número de documentos en los que el tópico se encuentra entre las dos mayores afinidades; incluye empates. En K=2 todos los documentos cumplen este criterio.", "scenario": "Las exclusiones se aplican a ambas etapas por identidad documental. Las auditorías conservan los registros originales.", "interpretation": "Las etiquetas propuestas requieren revisión. La validación experta exige una etiqueta, fundamento y referencia a evidencia exportada."}
    return payload


def load_saved_results(path):
    path = Path(path)
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.rsplit("/", 1)[-1] == "panorama_datos.json"]
            if len(names) != 1 or z.getinfo(names[0]).file_size > 100 * 1024 * 1024:
                raise ValueError("Se requiere un único panorama_datos.json de tamaño compatible")
            payload = json.loads(z.read(names[0]))
    else:
        payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema") not in ["observatorio-noa-panorama/0.1", "observatorio-noa-panorama/0.2"]:
        raise ValueError("El esquema de resultados no es compatible")
    if {s["id"] for s in payload["stages"]} != {"initial", "refined"}:
        raise ValueError("El paquete debe contener ambas etapas")
    for stage in payload["stages"]:
        dids = {d["id"] for d in stage["documents"]}
        if len(dids) != len(stage["documents"]) or len({d["uid"] for d in stage["documents"]}) != len(dids):
            raise ValueError("Identidad documental duplicada")
        for chunk in stage["chunks"]:
            if chunk["doc"] not in dids or chunk["text"] not in payload["texts"]:
                raise ValueError("Referencia de documento o texto incompleta")
            if hashlib.sha256(payload["texts"][chunk["text"]].encode()).hexdigest() != chunk["text"]:
                raise ValueError("La huella de un texto no coincide con su contenido")
        for doc in stage["documents"]:
            for values in doc["profiles"].values():
                if any(v is not None and (not math.isfinite(float(v)) or float(v) < 0) for v in values.values()):
                    raise ValueError("Perfil documental inválido")
    payload = enrich_payload(payload)
    payload["reused_results"] = {"filename": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "embedding_checks": "preservados del paquete; las matrices no se vuelven a cargar por esta ruta"}
    return payload


def export_analyses(payload, directory):
    directory = Path(directory)
    profile_rows, influence_rows, lift_rows = [], [], []
    for stage in payload["stages"]:
        for layer in stage["layers"]:
            for group in provincial_profiles(payload, stage["id"], layer):
                for mode, key in [("documents", "observed"), ("sources", "balanced")]:
                    p = group[key]
                    for topic in range(len(stage["layers"][layer]["topics"])):
                        profile_rows.append({"stage": stage["id"], "layer": layer, "province": group["province"], "mode": mode, "topic": topic, "affinity": float(p[topic]) if p is not None else None, "n_documents": group["n"], "n_cfi": group["cfi"], "n_saij": group["saij"], "available": p is not None})
                        influence_rows += influence(payload, stage["id"], group["province"], topic, layer, mode)
            for mode in ["documents", "sources"]:
                lift_rows += concentration(payload, stage["id"], layer, mode)
    tables = {"perfiles_observados_y_equilibrados.csv": profile_rows, "aporte_documental_y_exclusion.csv": influence_rows, "concentracion_relativa.csv": lift_rows, "etiquetas_propuestas.csv": payload["label_proposals"], "revision_catalogacion.csv": payload["catalogue_reviews"]}
    for name, rows in tables.items():
        pd.DataFrame(rows).to_csv(directory / name, index=False, encoding="utf-8-sig")
    (directory / "metodos_analiticos.json").write_text(json.dumps(payload["analysis_methods"], ensure_ascii=False, indent=2), encoding="utf-8")
    return {name: len(rows) for name, rows in tables.items()}
