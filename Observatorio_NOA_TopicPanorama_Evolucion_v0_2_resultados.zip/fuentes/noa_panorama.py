"""Visor de resultados existentes. No ajusta LDA, BERTopic ni embeddings."""
from __future__ import annotations

import ast
import ctypes as C
import ctypes.util
import hashlib
import json
import math
import re
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import numpy as np
import pandas as pd

from noa_analysis import enrich_payload, export_analyses

VERSION = "0.2.0"
PROVINCES = ["Catamarca", "La Rioja", "Santiago del Estero"]


def normalized(value):
    value = unicodedata.normalize("NFKD", str(value or ""))
    return re.sub(r"[^a-z0-9]+", " ", "".join(c for c in value if not unicodedata.combining(c)).lower()).strip()


def text(value):
    if value is None or (not isinstance(value, (list, dict)) and pd.isna(value)):
        return ""
    return str(value)


def number(value):
    try:
        n = float(value)
        return round(n, 9) if math.isfinite(n) else None
    except (ValueError, TypeError):
        return None


def truth(value):
    if isinstance(value, str):
        return value.lower() in ("true", "1", "yes", "si", "sí")
    return bool(value) if pd.notna(value) else False


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_target(root, name):
    name = name.replace("\\", "/")
    p = PurePosixPath(name)
    if p.is_absolute() or ".." in p.parts or re.match(r"^[A-Za-z]:", name):
        raise ValueError(f"Ruta no permitida dentro del archivo: {name}")
    target = root.joinpath(*p.parts)
    if not target.resolve().is_relative_to(root.resolve()):
        raise ValueError("La ruta sale del directorio de extracción")
    return target


def extract_rar(source, root):
    """Libarchive del sistema; compatible con el RAR5 suministrado y con Colab/Linux."""
    library = ctypes.util.find_library("archive")
    if not library:
        raise RuntimeError("RAR requiere libarchive. En este entorno, extraé el RAR y usá la carpeta o comprimila como ZIP.")
    lib = C.CDLL(library)
    def bind(name, result, arguments):
        f = getattr(lib, name)
        f.restype, f.argtypes = result, arguments
        return f
    new = bind("archive_read_new", C.c_void_p, [])
    filters = bind("archive_read_support_filter_all", C.c_int, [C.c_void_p])
    formats = bind("archive_read_support_format_all", C.c_int, [C.c_void_p])
    opening = bind("archive_read_open_filename", C.c_int, [C.c_void_p, C.c_char_p, C.c_size_t])
    next_header = bind("archive_read_next_header", C.c_int, [C.c_void_p, C.POINTER(C.c_void_p)])
    pathname = bind("archive_entry_pathname", C.c_char_p, [C.c_void_p])
    size = bind("archive_entry_size", C.c_int64, [C.c_void_p])
    kind = bind("archive_entry_filetype", C.c_uint, [C.c_void_p])
    read = bind("archive_read_data", C.c_ssize_t, [C.c_void_p, C.c_void_p, C.c_size_t])
    error = bind("archive_error_string", C.c_char_p, [C.c_void_p])
    free = bind("archive_read_free", C.c_int, [C.c_void_p])
    a = new()
    filters(a); formats(a)
    try:
        if opening(a, str(source).encode(), 10240) < 0:
            raise RuntimeError(text(error(a)))
        total = 0
        while True:
            entry = C.c_void_p()
            status = next_header(a, C.byref(entry))
            if status == 1:
                break
            if status < 0:
                raise RuntimeError(error(a).decode(errors="replace"))
            target = safe_target(root, pathname(entry).decode("utf-8", errors="strict"))
            if kind(entry) == 0o040000:
                target.mkdir(parents=True, exist_ok=True)
                continue
            if kind(entry) != 0o100000:
                raise ValueError("Solo se admiten archivos regulares y carpetas")
            nbytes = size(entry)
            total += nbytes
            if total > 512 * 1024 * 1024:
                raise ValueError("La exportación supera el límite de extracción de 512 MiB")
            target.parent.mkdir(parents=True, exist_ok=True)
            buffer = C.create_string_buffer(1024 * 1024)
            written = 0
            with target.open("wb") as out:
                while True:
                    n = read(a, buffer, len(buffer))
                    if n == 0:
                        break
                    if n < 0:
                        raise RuntimeError(error(a).decode(errors="replace"))
                    out.write(buffer.raw[:n]); written += n
            if written != nbytes:
                raise ValueError(f"Tamaño extraído incorrecto: {target.name}")
    finally:
        free(a)


def open_export(source, workdir):
    source = Path(source).expanduser().resolve()
    if source.is_dir():
        h = hashlib.sha256()
        for p in sorted(source.rglob("*")):
            if p.is_file() and not any(part.startswith(".") for part in p.relative_to(source).parts):
                h.update(p.relative_to(source).as_posix().encode())
                h.update(b"\x00")
                h.update(sha256(p).encode())
                h.update(b"\x00")
        return source, {"filename": source.name, "sha256": h.hexdigest(), "kind": "directory", "hash_basis": "rutas relativas y SHA-256 de los archivos"}
    if not source.is_file():
        raise FileNotFoundError(f"No se encontró {source}")
    digest = sha256(source)
    root = Path(workdir) / digest[:16]
    marker = root / ".extraction_complete"
    if not marker.exists():
        root.mkdir(parents=True, exist_ok=True)
        if source.suffix.lower() == ".zip":
            with zipfile.ZipFile(source) as z:
                if sum(i.file_size for i in z.infolist()) > 512 * 1024 * 1024:
                    raise ValueError("El ZIP supera 512 MiB al extraerse")
                for item in z.infolist():
                    target = safe_target(root, item.filename)
                    if ((item.external_attr >> 16) & 0o170000) == 0o120000:
                        raise ValueError("No se admiten enlaces simbólicos")
                    if item.is_dir():
                        target.mkdir(parents=True, exist_ok=True)
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(z.read(item))
        elif source.suffix.lower() == ".rar":
            extract_rar(source, root)
        else:
            raise ValueError("Usá una carpeta extraída, un ZIP o un RAR")
        marker.write_text(digest)
    return root, {"filename": source.name, "sha256": digest, "kind": source.suffix.lower()[1:]}


class Export:
    def __init__(self, root):
        self.root = Path(root)

    def file(self, name, required=True):
        matches = list(self.root.rglob(name))
        if len(matches) != 1:
            if not matches and not required:
                return None
            raise ValueError(f"Se esperaba un único {name}; encontrados: {len(matches)}")
        return matches[0]

    def table(self, name, required=True):
        p = self.file(name, required)
        if p is None:
            return pd.DataFrame()
        return pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_csv(p)

    def json(self, name):
        return json.loads(self.file(name).read_text(encoding="utf-8-sig"))


def descriptor_words(descriptor):
    """Extrae la lista explícita de palabras; evita tomar ejemplos como descriptores."""
    descriptor = text(descriptor)
    match = re.search(r"\[[^\]]+\]", descriptor)
    if match:
        try:
            values = ast.literal_eval(match.group())
            if isinstance(values, list):
                return [str(v) for v in values]
        except (ValueError, SyntaxError):
            pass
    return list(dict.fromkeys(v.strip() for v in descriptor.split("|") if v.strip()))[:15]


def document_identity(row):
    year = number(row.get("year_matrix"))
    raw = "|".join([normalized(row.get("source")), normalized(row.get("province")), str(int(year)) if year else "", normalized(row.get("title"))])
    return hashlib.sha256(raw.encode()).hexdigest()[:20]


def as_topics(frame, columns):
    return {str(i): number(frame.get(c)) for i, c in enumerate(columns)}


def load_stage(root, stage_id, source, store):
    export = Export(root)
    initial = stage_id == "initial"
    manifest = export.json("run_manifest.json" if initial else "rag_run_manifest_v302.json")
    docs = export.table("documents.parquet" if initial else "rag_document_index.parquet")
    chunks = export.table("chunks_raw.parquet" if initial else "rag_chunk_index.parquet")
    for frame, label, key in [(docs, "documentos", "doc_id"), (chunks, "fragmentos", "chunk_id")]:
        if frame[key].isna().any() or frame[key].duplicated().any():
            raise ValueError(f"Identificadores ausentes o duplicados en {label} de {stage_id}")
    if not chunks.doc_id.isin(docs.doc_id).all():
        raise ValueError("Hay fragmentos sin documento de origen")
    bt_columns = [f"bt_topic_{i}" for i in range(3)] if initial else [f"sub_bt_topic_{i}" for i in range(8)]
    layers = {}
    if initial:
        ld = export.table("lda_document_topics.parquet").set_index("doc_id")
        bt = export.table("bertopic_document_topics.csv").set_index("doc_id")
        if manifest.get("selected_lda_k") != 3 or manifest.get("bertopic_topics") != 3:
            raise ValueError("El adaptador inicial v0.1 corresponde a LDA K=3 y BERTopic global de 3 tópicos. Esta exportación requiere otro adaptador.")
        for frame, columns in [(ld, [f"lda_topic_{i}" for i in range(3)]), (bt, bt_columns + ["bt_outlier"])]:
            if not set(columns).issubset(frame.columns):
                raise ValueError("La exportación inicial no incluye todos los perfiles esperados")
        info = export.table("bertopic_topic_info.csv")
        topics = []
        for _, r in info.loc[info.Topic.ge(0)].sort_values("Topic").iterrows():
            words = ast.literal_eval(r.Representation)
            topics.append({"id": str(int(r.Topic)), "words": [{"term": w, "weight": None} for w in words], "training_count": int(r.Count)})
        terms = export.table("lda_topic_terms.csv")
        lda_topics = [{"id": str(int(i)), "words": [{"term": str(r.term), "weight": number(r.weight)} for _, r in group.sort_values("rank").iterrows()]} for i, group in terms.groupby("lda_topic", sort=True)]
        layers["bt"] = {"name": "BERTopic global · 3 tópicos", "topics": topics, "basis": "Afinidades documentales exportadas, condicionadas a masa temática", "weighted_terms": False}
        layers["lda3"] = {"name": "LDA · K=3", "topics": lda_topics, "basis": "Distribuciones documentales LDA exportadas", "weighted_terms": True}
        training = export.table("bertopic_training_assignments.csv").set_index("chunk_id")
        if not training.index.isin(chunks.chunk_id).all():
            raise ValueError("Hay asignaciones de entrenamiento sin fragmento")
        policy = export.table("chunks_policy_view.parquet").set_index("chunk_id")
        crosswalk = export.table("lda_bertopic_crosswalk.csv").to_dict("records")
        robustness = export.table("bertopic_semantic_robustness.csv").to_dict("records")
    else:
        ld = bt = docs.set_index("doc_id")
        expected = bt_columns + [f"lda_k{k}_topic_{i}" for k in [2, 3] for i in range(k)]
        if not set(expected).issubset(docs.columns):
            raise ValueError("El adaptador refinado v0.1 requiere los perfiles LDA K=2/K=3 y los 8 microtópicos sustantivos de RAG v3.0.2")
        topics = []
        for _, r in export.table("rag_microtopic_descriptors.csv").sort_values("topic_id").iterrows():
            topics.append({"id": str(int(r.topic_id)), "words": [{"term": w, "weight": None} for w in descriptor_words(r.descriptor)]})
        layers["bt"] = {"name": "BERTopic sustantivo · 8 microtópicos", "topics": topics, "basis": "Afinidades documentales del nivel sustantivo exportadas", "weighted_terms": False}
        for k in [2, 3]:
            lda_topics = []
            for _, r in export.table(f"rag_lda_k{k}_descriptors.csv").sort_values("topic_id").iterrows():
                lda_topics.append({"id": str(int(r.topic_id)), "words": [{"term": w, "weight": None} for w in descriptor_words(r.descriptor)]})
            layers[f"lda{k}"] = {"name": f"LDA · K={k}" + (" · principal" if k == 2 else " · refinamiento"), "topics": lda_topics, "basis": "Distribuciones documentales LDA exportadas", "weighted_terms": False}
        crosswalk, robustness = [], []
        training = policy = None

    records, doc_by_id = [], {}
    for _, row in docs.iterrows():
        doc_id = str(row.doc_id)
        origin = text(row.get("policy_view_origin"))
        full = origin in ("full_text", "ocr_text") or (number(row.get("word_count")) or 0) > 0
        d = {"id": doc_id, "uid": document_identity(row), "title": text(row.get("title")), "province": text(row.get("province")), "source": text(row.get("source")), "year": number(row.get("year_matrix")), "year_catalog": number(row.get("year_catalog")), "period": text(row.get("period")), "link": text(row.get("link")), "summary": text(row.get("summary")), "origin": origin, "full": full, "regional": truth(row.get("regional_context")), "compare": truth(row.get("include_in_province_comparison")), "words": number(row.get("word_count")), "text": store(text(row.get("document_text"))), "model_text": store(text(row.get("policy_view_model"))), "profiles": {}}
        for layer in layers:
            cols = bt_columns if layer == "bt" else [f"lda_topic_{i}" if initial else f"lda_k{layer[-1]}_topic_{i}" for i in range(len(layers[layer]["topics"]))]
            source_frame = bt if layer == "bt" else ld
            values = as_topics(source_frame.loc[doc_id], cols) if doc_id in source_frame.index else {str(i): None for i in range(len(cols))}
            d["profiles"][layer] = values
        d["bt_outlier"] = number(bt.loc[doc_id].get("bt_outlier")) if initial and doc_id in bt.index else None
        if d["uid"] in {x["uid"] for x in records}:
            raise ValueError("Identidad documental ambigua: revisar fuente, provincia, año y título")
        records.append(d); doc_by_id[doc_id] = d

    chunk_records = []
    for _, row in chunks.iterrows():
        cid, did = str(row.chunk_id), str(row.doc_id)
        if initial:
            assignment = number(training.loc[cid].topic) if cid in training.index else None
            weights = None
            policy_text = text(policy.loc[cid].get("policy_view")) if cid in policy.index else ""
            basis = "entrenamiento exportado" if cid in training.index else "sin asignación temática exportada"
            citation = f"[{did}, {cid}]"
        else:
            assignment = number(row.get("substantive_topic"))
            weights = as_topics(row, bt_columns) if pd.notna(row.get(bt_columns[0])) else None
            policy_text = text(row.get("policy_view"))
            basis = "propagación sustantiva exportada" if assignment is not None else "fuera del nivel sustantivo"
            citation = text(row.get("citation")) or f"[{did}, {cid}]"
        chunk_records.append({"id": cid, "doc": did, "uid": doc_by_id[did]["uid"], "text": store(text(row.get("text_raw"))), "policy": store(policy_text), "heading": text(row.get("heading")), "page_start": number(row.get("page_start")), "page_end": number(row.get("page_end")), "article": text(row.get("article_ref")), "origin": text(row.get("text_origin")), "assignment": int(assignment) if assignment is not None else None, "assignment_basis": basis, "weights": weights, "citation": citation})

    arrays = []
    for name, expected in [("document_embeddings.npy" if initial else "rag_document_embeddings.npy", len(docs)), ("chunk_embeddings.npy" if initial else "rag_chunk_embeddings.npy", len(chunks))]:
        p = export.file(name, required=False)
        if p is not None:
            a = np.load(p, mmap_mode="r", allow_pickle=False)
            ok = a.ndim == 2 and len(a) == expected and bool(np.isfinite(a).all())
            if not ok:
                raise ValueError(f"Embeddings inválidos: {name}")
            arrays.append({"name": name, "shape": list(a.shape), "finite": True})
    return {"id": stage_id, "name": "Inicial" if initial else "Refinada", "export": source, "manifest": manifest, "documents": records, "chunks": chunk_records, "layers": layers, "exported_crosswalk": crosswalk, "robustness": robustness, "embedding_checks": arrays}


def conditional(values):
    vals = np.array([v if v is not None else np.nan for v in values], dtype=float)
    if not np.isfinite(vals).all() or vals.sum() <= 0:
        return None
    return vals / vals.sum()


def correspondence_table(payload, layer="bt"):
    a, b = payload["stages"]
    if layer not in a["layers"] or layer not in b["layers"]:
        return pd.DataFrame()
    ad = {d["uid"]: d for d in a["documents"] if d["full"] and d["compare"] and not d["regional"]}
    bd = {d["uid"]: d for d in b["documents"] if d["full"] and d["compare"] and not d["regional"]}
    common = sorted(ad.keys() & bd.keys())
    rows, aa, bb, accepted = [], [], [], []
    for uid in common:
        x = conditional(list(ad[uid]["profiles"][layer].values()))
        y = conditional(list(bd[uid]["profiles"][layer].values()))
        if x is not None and y is not None:
            aa.append(x); bb.append(y); accepted.append(uid)
    if not aa:
        return pd.DataFrame()
    aa, bb = np.asarray(aa), np.asarray(bb)
    for i in range(aa.shape[1]):
        for j in range(bb.shape[1]):
            denom = np.linalg.norm(aa[:, i]) * np.linalg.norm(bb[:, j])
            rows.append({"layer": layer, "initial_topic": i, "refined_topic": j, "document_cosine": float(np.dot(aa[:, i], bb[:, j]) / denom) if denom else None, "common_documents": len(accepted), "basis": "co-distribución documental; no probabilidad ni descendencia del tópico"})
    return pd.DataFrame(rows)


def build_payload(initial_path, refined_path, workdir):
    workdir = Path(workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    texts = {}
    def store(value):
        if not value:
            return None
        key = hashlib.sha256(value.encode()).hexdigest()
        texts.setdefault(key, value)
        return key
    stages = []
    for stage_id, path in [("initial", initial_path), ("refined", refined_path)]:
        root, source = open_export(path, workdir / "inputs")
        stages.append(load_stage(root, stage_id, source, store))
    a, b = stages
    ad, bd = ({d["uid"]: d for d in s["documents"]} for s in stages)
    coverage = []
    for uid in sorted(ad.keys() | bd.keys()):
        x, y = ad.get(uid), bd.get(uid)
        d = y or x
        coverage.append({"uid": uid, "initial_doc": x["id"] if x else None, "refined_doc": y["id"] if y else None, "title": d["title"], "source": d["source"], "province": d["province"], "regional": d["regional"], "initial_fulltext": bool(x and x["full"]), "refined_fulltext": bool(y and y["full"]), "initial_origin": x["origin"] if x else None, "refined_origin": y["origin"] if y else None, "identity_basis": "fuente + provincia + año matriz + título normalizados"})
    ac = {(c["uid"], c["id"]): c for c in a["chunks"]}
    bc = {(c["uid"], c["id"]): c for c in b["chunks"]}
    lineage = []
    for key in sorted(ac.keys() | bc.keys()):
        x, y = ac.get(key), bc.get(key)
        unchanged = bool(x and y and x["text"] == y["text"])
        lineage.append({"uid": key[0], "chunk_id": key[1], "initial_present": x is not None, "refined_present": y is not None, "same_raw_text": unchanged if x and y else None, "status": "conservado" if unchanged else "modificado" if x and y else "incorporado" if y else "no presente en refinada", "initial_assignment": x["assignment"] if x else None, "refined_assignment": y["assignment"] if y else None, "refined_assignment_basis": y["assignment_basis"] if y else None})
    payload = {"schema": "observatorio-noa-panorama/0.1", "version": VERSION, "created_at": datetime.now(timezone.utc).isoformat(), "provinces": PROVINCES, "texts": texts, "stages": stages, "coverage": coverage, "lineage": lineage, "references": [{"title": "TopicPanorama: a Full Picture of Relevant Topics", "doi": "10.1109/VAST.2014.7042494", "url": "https://shixialiu.com/publications/TopicPanorama/index.htm"}], "limitations": ["Adaptación de funciones visuales: no replica los algoritmos CTM, BRT ni el emparejamiento húngaro del sistema original.", "Las relaciones entre etapas expresan co-distribución documental o coincidencia de fragmentos con asignación exportada; no son equivalencias certificadas.", "Inicial: los perfiles BERTopic se condicionan a la masa de los tres tópicos, excluyendo la masa atípica; refinada: se usan las afinidades documentales sustantivas normalizadas ya exportadas.", "Los descriptores refinados no incluyen pesos de términos LDA ni centroides originales. No se inventan esos valores.", "El eje de etapas representa versiones del procesamiento. Los años corresponden a los documentos.", "Los dos estados no permiten atribuir causalmente el cambio a cada intervención de procesamiento.", "Las similitudes, afinidades y métricas de estabilidad no son probabilidades calibradas de verdad."]}
    payload["correspondences"] = correspondence_table(payload).to_dict("records")
    payload["correspondences_lda3"] = correspondence_table(payload, "lda3").to_dict("records")
    return enrich_payload(payload)


def write_project(payload, template, output):
    payload = enrich_payload(payload)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    data_json = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    template = Path(template).read_text(encoding="utf-8")
    html = template.replace("__NOA_PAYLOAD__", data_json.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))
    html_path = output / "Observatorio_NOA_TopicPanorama_Evolucion_v0_2.html"
    html_path.write_text(html, encoding="utf-8")
    (output / "panorama_datos.json").write_text(data_json, encoding="utf-8")
    pd.DataFrame(payload["coverage"]).to_csv(output / "auditoria_documentos.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(payload["lineage"]).to_csv(output / "auditoria_fragmentos.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(payload["correspondences"]).to_csv(output / "correspondencias_documentales_bt.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(payload["correspondences_lda3"]).to_csv(output / "correspondencias_documentales_lda3.csv", index=False, encoding="utf-8-sig")
    analysis_tables = export_analyses(payload, output)
    report = {"analytical_tables": analysis_tables, "reused_results": payload.get("reused_results"), "version": VERSION, "documents": [{"stage": s["id"], "catalogued": len(s["documents"]), "fulltext": sum(d["full"] for d in s["documents"]), "provincial_fulltext": sum(d["full"] and d["compare"] and not d["regional"] for d in s["documents"]), "chunks": len(s["chunks"]), "input": s["export"], "embedding_checks": s["embedding_checks"]} for s in payload["stages"]], "chunk_lineage": {status: sum(r["status"] == status for r in payload["lineage"]) for status in sorted({r["status"] for r in payload["lineage"]})}, "recovered_documents": [r for r in payload["coverage"] if not r["initial_fulltext"] and r["refined_fulltext"]], "limitations": payload["limitations"]}
    (output / "resumen_validacion.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return html_path, report
