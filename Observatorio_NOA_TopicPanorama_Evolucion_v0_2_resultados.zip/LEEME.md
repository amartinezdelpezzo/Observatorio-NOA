# Observatorio NOA · TopicPanorama · v0.2

## Explorar directamente

Abrí `Observatorio_NOA_TopicPanorama_Evolucion_v0_2.html` en un navegador. Contiene los datos y funciona sin conexión. Las nuevas herramientas están en **Lectura provincial y respaldo documental**, debajo de los panoramas.

## Ejecutar en Colab

1. Abrí `Observatorio_NOA_TopicPanorama_Evolucion_v0_2.ipynb` y ejecutá las celdas en orden.
2. El modo predeterminado, `resultados`, solicita un único archivo: el ZIP de resultados de la v0.1 que ya ejecutaste, o un ZIP de resultados de la v0.2. También acepta `panorama_datos.json`.
3. Para reconstruir desde las exportaciones originales, elegí `MODO_CARGA = "originales"` y cargá `outputs_1821.rar` y `observatorio_noa_rag_v302.zip`. Se admiten los nombres con sufijos y carpetas extraídas.
4. El visor se genera en ambos modos. Se pueden descargar todas las tablas y las fuentes en un ZIP.

La ruta de resultados verifica las identidades y huellas de los textos conservados en el JSON; mantiene las comprobaciones de embeddings de la ejecución original, sin volver a cargar matrices ausentes del ZIP de resultados. La ruta original vuelve a verificar las matrices disponibles. No se vuelven a ajustar modelos.

## Tres incorporaciones

### Perfiles y fuentes

El panel muestra juntos el promedio observado, con igual peso por documento, y el promedio equilibrado, con 50 % para CFI y 50 % para SAIJ dentro de cada provincia. El equilibrio queda **no disponible** si falta una fuente. Una selección de fuente única utiliza la ponderación por documento.

### Aporte y exclusión

Seleccioná etapa, provincia y tópico. El aporte de cada documento al tópico suma 100 % entre documentos activos. La tabla distingue aporte, afinidad documental y perfil obtenido al retirar ese documento. El CSV incluye también el peso utilizado en el promedio.

Marcar **Excluir** retira temporalmente el documento de ambas etapas, por su identidad documental. Actualiza perfiles, relaciones y concentraciones; mantiene la auditoría de los registros originales. **Restaurar** revierte el escenario. La comparación conserva los perfiles documentales calculados; no representa un nuevo ajuste LDA o BERTopic.

Si al retirar un documento se pierde una fuente, la media equilibrada queda no disponible. La media observada puede seguir consultándose. Guardar sesión conserva el escenario y las revisiones.

### Concentración relativa

Se calcula `L(provincia,tópico) = afinidad provincial / promedio de afinidades de las provincias disponibles`, con el mismo peso por provincia. Un valor de 1 es el promedio; 1,5 expresa una afinidad 50 % mayor. Se requieren al menos dos provincias. El filtro provincial conserva la referencia, mientras los filtros de fuente, período, búsqueda, universo y exclusiones sí se aplican a ella.

El soporte cuenta documentos en los que el tópico está entre las dos mayores afinidades, incluidos empates. En K=2 todos los documentos cumplen el criterio. El borde resalta, de forma exploratoria, concentración ≥ 1,2 y soporte en al menos dos documentos; ambos umbrales se pueden modificar. Estas cifras no certifican relevancia política ni confianza estadística.

## Etiquetas interpretativas

El modo inicial conserva las palabras originales. Se puede elegir **Propuestas interpretativas** o **Solo interpretaciones validadas**. Hay ocho propuestas para el nivel sustantivo refinado, acompañadas por pasajes concretos. Todas empiezan pendientes de validación.

Para marcar una etiqueta como validada, el investigador debe registrar etiqueta, fundamento y referencia a un documento o fragmento exportado. Las etiquetas y notas se guardan como anotaciones, junto con fecha de revisión. Las sesiones v0.1 se pueden importar; las etiquetas anteriores se consideran propuestas si carecen de esos registros.

La discrepancia entre el título de DOC_016 —bosques nativos— y la referencia del texto a bosques cultivados se conserva como observación pendiente. El título original permanece intacto.

## Archivos analíticos

- `perfiles_observados_y_equilibrados.csv`: ambas ponderaciones y disponibilidad.
- `aporte_documental_y_exclusion.csv`: aporte y exclusión individual para cada etapa, capa, provincia y tópico, en el escenario completo.
- `concentracion_relativa.csv`: concentración, referencia y soporte.
- `etiquetas_propuestas.csv`, `revision_catalogacion.csv` y `metodos_analiticos.json`.
- Auditorías documentales y de fragmentos y correspondencias entre etapas conservadas.
- `figuras/`: figuras de las nuevas herramientas exportadas desde el visor.

Las tablas generales incluidas corresponden al escenario completo. **Descargar tabla actual** en el visor incluye los filtros y exclusiones en cada fila. SVG y PNG exportan la herramienta analítica actualmente seleccionada.

## Alcance

Las etapas identifican versiones de procesamiento; los períodos corresponden a años documentales. Los identificadores de tópicos son locales a cada ajuste. Inicial: tres tópicos BERTopic globales. Refinada: ocho microtópicos sustantivos, con un modelo global de dos tópicos conservado en el manifiesto. Más tópicos no implica mayor calidad.

La etapa inicial contiene 16 textos completos; la refinada, 19. Los 1.704 fragmentos originales se conservan con igual identificador y texto; se agregan 57 por OCR. ATACALAR se consulta como contexto regional y queda fuera de los perfiles provinciales.

Los perfiles iniciales BERTopic se condicionan a la masa de los tres tópicos, excluyendo la masa atípica. Los ocho perfiles sustantivos refinados ya vienen normalizados. Afinidades y similitudes no son probabilidades calibradas. Las palabras ponderadas LDA se conservan donde fueron exportadas; los descriptores refinados carecen de sus pesos individuales.

Esta es una adaptación de la exploración de TopicPanorama con relaciones documentales, evidencia y anotaciones. No replica CTM, BRT ni el optimizador húngaro incremental original. Dos estados permiten documentar cambios conjuntos; no atribuir causalmente diferencias a cada intervención de limpieza o modelado.

Referencia: Liu, S., Wang, X., Chen, J., Zhu, J. y Guo, B. (2014). TopicPanorama: a Full Picture of Relevant Topics. IEEE VAST. https://doi.org/10.1109/VAST.2014.7042494
